export interface IEvent {
  name : string,
  image : string,
  date : string,
  price : number,
  type : string,
  info : string
}
