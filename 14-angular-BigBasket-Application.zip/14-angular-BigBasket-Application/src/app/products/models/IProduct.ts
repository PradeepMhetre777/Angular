export interface IProduct {
  _id:string,
  name:string,
  image:string,
  price:number,
  qty:number,
  info:string
}
